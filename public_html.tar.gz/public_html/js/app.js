import { animation } from "./animation.js";
import { header } from "./header.js";



const d = document;
d.addEventListener("DOMContentLoaded", e=>{
  header();
  animation();
 
});