import { formulario } from "./formulario.js";
import { header } from "./header.js";


const d = document;
d.addEventListener("DOMContentLoaded", e=>{
  header();
  formulario();
 
});